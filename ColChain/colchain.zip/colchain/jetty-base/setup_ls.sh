#!/bin/bash

echo "Starting server 3000"
curl "http://172.21.233.15:3000/experiments?mode=start&config=config.json&dir=data&setup=setup&id=0&nodes=32" > curl_${i}

for i in {001..031}
do
  echo "Starting server 3${i}"
  ii=$(echo $i | sed 's/^0*//')
  curl "http://172.21.233.15:3${i}/experiments?mode=start&config=config.json&dir=data&setup=setup&id=${ii}&nodes=32" > curl_${i}
done
