#!/bin/bash

for i in {000..031}
do
  echo "Starting server 3${i}"
  nohup java -Xmx8G -jar $JETTY_HOME/start.jar jetty.http.port=3${i} > out_${i} &
done
