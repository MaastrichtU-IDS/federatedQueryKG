#!/bin/bash

pkill -f -9 start.jar
